import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import {
  ArrowRight, Mail, Phone, Instagram, Palette, PenTool, Package, Layout,
  Printer, Sparkles, Image as ImageIcon, Megaphone, Layers, Search, Lightbulb,
  Wand2, Send, Check, Star, Zap, Heart, Eye, Target, Rocket, Loader2,
} from "lucide-react";
import emailjs from "@emailjs/browser";
import { toast } from "sonner";
import heroPortrait from "@/assets/hero-portrait.jpg";

const EMAILJS_SERVICE_ID = "service_4jqz5lq";
const EMAILJS_TEMPLATE_ID = "template_l8bszxh";
const EMAILJS_PUBLIC_KEY = "GEWBgAxlTDb7-_LMB";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "S Divya Jennifer — Freelance Graphic Designer" },
      { name: "description", content: "Portfolio of S Divya Jennifer: branding, logo design, packaging, print, UI/UX and digital design." },
    ],
  }),
  component: Index,
});

const nav = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Services", href: "#services" },
  { label: "Portfolio", href: "#portfolio" },
  { label: "Contact", href: "#contact" },
];

const stats = [
  { value: 120, suffix: "+", label: "Creative Concepts" },
  { value: 9, suffix: "", label: "Design Categories" },
  { value: 4, suffix: "", label: "Software Mastered" },
  { value: 100, suffix: "%", label: "Passion for Craft" },
];

const skills = [
  { name: "Logo Design", level: 96, icon: PenTool },
  { name: "Brand Identity", level: 94, icon: Sparkles },
  { name: "Adobe Photoshop", level: 92, icon: ImageIcon },
  { name: "Adobe Illustrator", level: 95, icon: PenTool },
  { name: "CorelDRAW", level: 88, icon: Palette },
  { name: "Figma", level: 90, icon: Layout },
  { name: "UI/UX Design", level: 87, icon: Layout },
  { name: "Packaging Design", level: 89, icon: Package },
  { name: "Print Design", level: 91, icon: Printer },
  { name: "Social Media", level: 93, icon: Megaphone },
  { name: "Illustration", level: 85, icon: Wand2 },
];

const services = [
  { icon: PenTool, title: "Logo Design", desc: "Distinctive marks built from strategy and story — timeless, versatile, unmistakable." },
  { icon: Sparkles, title: "Brand Identity Design", desc: "Complete identity systems that align voice, color, and craft across every touchpoint." },
  { icon: Package, title: "Packaging Design", desc: "Shelf-ready structures that turn products into experiences worth photographing." },
  { icon: Megaphone, title: "Social Media Design", desc: "Scroll-stopping visual systems built for consistency and engagement." },
  { icon: Printer, title: "Print Design", desc: "Editorial, collateral, and stationery with a refined, tactile finish." },
  { icon: Layout, title: "UI/UX Design", desc: "Interfaces that feel obvious — clean hierarchy, considered motion, real usability." },
  { icon: Wand2, title: "Illustration", desc: "Custom illustration to give your brand a voice no stock library can match." },
  { icon: ImageIcon, title: "Photo Editing", desc: "Retouching and manipulation that keeps images honest and elevated." },
  { icon: Layers, title: "Marketing Collateral", desc: "Decks, brochures, and campaign kits that keep every asset on-brand." },
];

const portfolio = [
  { title: "Ember Coffee Co.", category: "Branding", tools: "Illustrator, Photoshop", palette: ["#e85d3a", "#1a1a1a", "#f0d78c", "#faf8f5"], desc: "A warm, artisan-roaster identity built around ritual and slow mornings." },
  { title: "Nova Skincare", category: "Packaging", tools: "Illustrator, Dimension", palette: ["#f8e8ee", "#c9a0dc", "#2d2d2d", "#e8c5d0"], desc: "Minimal packaging system for a clean beauty concept line." },
  { title: "Pulse Fitness", category: "UI/UX", tools: "Figma", palette: ["#0d1b2a", "#2dd4a8", "#73ffb8", "#ffffff"], desc: "Mobile-first training app with adaptive workout flows." },
  { title: "Loom & Linen", category: "Logos", tools: "Illustrator", palette: ["#c4654a", "#87a878", "#4a6741", "#faf8f5"], desc: "Handcrafted mark for a small-batch textile studio." },
  { title: "Orbit Media", category: "Branding", tools: "Illustrator, After Effects", palette: ["#0a0a1a", "#4f46e5", "#e94560", "#ffffff"], desc: "Editorial identity for an independent podcast network." },
  { title: "Bloom Bakery", category: "Social Media", tools: "Photoshop, Figma", palette: ["#ff6b6b", "#ee5a70", "#fecaca", "#574b90"], desc: "A twelve-week social system built on hand-lettered posts." },
  { title: "Terra Ceramics", category: "Print", tools: "InDesign, Illustrator", palette: ["#6b3a2a", "#a0522d", "#e8c07a", "#f5f0e8"], desc: "A quiet, texture-forward catalog for a ceramics studio." },
  { title: "Fable Books", category: "Packaging", tools: "Illustrator", palette: ["#f5f3ee", "#2d2d2d", "#c9a84c", "#0d0d0d"], desc: "Book jacket system for a boutique fiction imprint." },
];

const filters = ["All", "Branding", "Logos", "UI/UX", "Packaging", "Social Media", "Print"];

const process = [
  { icon: Search, title: "Discovery", desc: "Deep dive into your goals, audience, and market." },
  { icon: Lightbulb, title: "Research", desc: "Competitive and cultural research to find the whitespace." },
  { icon: Wand2, title: "Concept", desc: "Multiple directions explored with rigor and intent." },
  { icon: Sparkles, title: "Refinement", desc: "Iterating with you until every detail earns its place." },
  { icon: Rocket, title: "Delivery", desc: "Final files, guidelines, and asset kits — production-ready." },
];

const software = [
  { name: "Photoshop", level: 92 },
  { name: "Illustrator", level: 95 },
  { name: "CorelDRAW", level: 88 },
  { name: "Figma", level: 90 },
];

const whys = [
  { icon: Lightbulb, title: "Creative Thinking", desc: "Ideas rooted in strategy, expressed with craft." },
  { icon: Eye, title: "Unique Visuals", desc: "No templates. Every project built from zero." },
  { icon: Target, title: "Attention to Detail", desc: "Kerning, curves, and margins — obsessively refined." },
  { icon: Heart, title: "Collaboration", desc: "Clear communication, shared decisions, no ego." },
  { icon: Zap, title: "Modern Trends", desc: "Contemporary but not trend-chasing." },
  { icon: Sparkles, title: "Future-Proof", desc: "Systems built to grow with your brand." },
  { icon: Check, title: "High Quality", desc: "Production-ready deliverables, every time." },
  { icon: Rocket, title: "Innovation", desc: "Always exploring new tools and techniques." },
];

function useCounter(target: number, duration = 1600) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    let start: number | null = null;
    let raf = 0;
    const step = (t: number) => {
      if (start === null) start = t;
      const p = Math.min((t - start) / duration, 1);
      setValue(Math.floor(p * target));
      if (p < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [target, duration]);
  return value;
}

function StatCard({ value, suffix, label }: { value: number; suffix: string; label: string }) {
  const n = useCounter(value);
  return (
    <div className="glass rounded-2xl p-6 transition-transform duration-300 hover:-translate-y-1">
      <div className="text-4xl font-bold text-gradient-ember md:text-5xl">{n}{suffix}</div>
      <div className="mt-2 text-sm text-muted-foreground">{label}</div>
    </div>
  );
}

function Index() {
  const [filter, setFilter] = useState("All");
  const [mouse, setMouse] = useState({ x: 50, y: 30 });

  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      setMouse({ x: (e.clientX / window.innerWidth) * 100, y: (e.clientY / window.innerHeight) * 100 });
    };
    window.addEventListener("mousemove", onMove);
    return () => window.removeEventListener("mousemove", onMove);
  }, []);

  const filtered = portfolio.filter(p => filter === "All" || p.category === filter);

  return (
    <div id="home" className="relative min-h-screen overflow-hidden text-foreground">
      {/* Mouse-follow gradient */}
      <div
        className="pointer-events-none fixed inset-0 z-0 opacity-40 transition-[background] duration-500"
        style={{
          background: `radial-gradient(600px circle at ${mouse.x}% ${mouse.y}%, oklch(0.72 0.19 45 / 0.15), transparent 60%)`,
        }}
      />
      {/* Floating shapes */}
      <div className="pointer-events-none fixed left-[8%] top-[20%] z-0 h-64 w-64 rounded-full bg-ember opacity-20 blur-3xl animate-float" />
      <div className="pointer-events-none fixed right-[6%] top-[60%] z-0 h-72 w-72 rounded-full opacity-15 blur-3xl animate-float-slow" style={{ background: "oklch(0.55 0.22 25)" }} />

      {/* NAV */}
      <header className="relative z-20 mx-auto max-w-7xl px-6 pt-6">
        <nav className="glass-strong flex items-center justify-between rounded-full px-6 py-3">
          <a href="#home" className="font-display text-lg font-bold">
            <span className="text-gradient-ember">Divya</span>Jennifer
          </a>
          <ul className="hidden items-center gap-8 md:flex">
            {nav.map(n => (
              <li key={n.href}>
                <a href={n.href} className="relative text-sm text-muted-foreground transition-colors hover:text-foreground after:absolute after:-bottom-1 after:left-0 after:h-0.5 after:w-full after:origin-right after:scale-x-0 after:bg-primary after:transition-transform after:duration-300 hover:after:origin-left hover:after:scale-x-100">
                  {n.label}
                </a>
              </li>
            ))}
          </ul>
          <a href="#contact" className="group inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 text-sm font-semibold text-background transition-transform hover:scale-105">
            Get in touch
            <span className="grid h-6 w-6 place-items-center rounded-full bg-ember text-white transition-transform group-hover:translate-x-0.5">
              <ArrowRight className="h-3.5 w-3.5" />
            </span>
          </a>
        </nav>
      </header>

      {/* HERO */}
      <section className="relative z-10 mx-auto max-w-7xl px-6 pt-10">
        <div className="relative overflow-hidden rounded-[2.5rem]" style={{ background: "var(--gradient-hero)" }}>
          <div className="relative grid grid-cols-1 gap-8 p-8 md:p-14 lg:grid-cols-12 lg:gap-6">
            <div className="lg:col-span-5 animate-reveal">
              <p className="mb-4 text-sm font-medium tracking-wide text-white/80">Hey, I'm S Divya Jennifer —</p>
              <h1 className="font-display text-5xl font-bold leading-[0.95] text-white md:text-6xl lg:text-7xl">
                Designing Brands That Leave <span className="text-gradient-ember">Lasting</span> Impressions
              </h1>
              <div className="mt-8 flex flex-wrap gap-3">
                <a href="#portfolio" className="inline-flex items-center gap-2 rounded-full bg-ember px-5 py-3 text-sm font-semibold text-white ember-glow transition-transform hover:scale-105">
                  View Portfolio <ArrowRight className="h-4 w-4" />
                </a>
                <a href="#services" className="inline-flex items-center gap-2 rounded-full border border-white/25 bg-white/10 px-5 py-3 text-sm font-semibold text-white backdrop-blur transition-colors hover:bg-white/20">
                  Explore Services
                </a>
                <a href="#contact" className="inline-flex items-center gap-2 rounded-full bg-white px-5 py-3 text-sm font-semibold text-background transition-transform hover:scale-105">
                  Contact Me
                </a>
              </div>
            </div>

            <div className="relative flex items-center justify-center lg:col-span-4">
              <div className="glass-strong rounded-[2rem] p-3 animate-float">
                <img
                  src={heroPortrait}
                  alt="S Divya Jennifer portrait"
                  width={1024}
                  height={1280}
                  className="h-[420px] w-[320px] rounded-[1.5rem] object-cover md:h-[480px] md:w-[360px]"
                />
              </div>
              {/* Floating socials */}
              <div className="absolute -left-2 top-8 flex flex-col gap-3">
                {[Mail, Phone, Instagram].map((Icon, i) => (
                  <a
                    key={i}
                    href="#contact"
                    className="glass grid h-11 w-11 place-items-center rounded-full text-white transition-transform hover:scale-110 animate-float"
                    style={{ animationDelay: `${i * 0.4}s` }}
                  >
                    <Icon className="h-4 w-4" />
                  </a>
                ))}
              </div>
            </div>

            <div className="flex flex-col justify-center lg:col-span-3 animate-reveal" style={{ animationDelay: "0.15s" }}>
              <h3 className="font-display text-2xl font-semibold text-white">
                Great design should feel invisible.
              </h3>
              <p className="mt-4 text-sm leading-relaxed text-white/75">
                Freelance graphic designer working across branding, logo design, visual identity,
                packaging, print, UI/UX, and digital experiences. I blend market strategy with
                creative intuition to build brand marks that connect and convert.
              </p>
            </div>
          </div>

          {/* Categories strip */}
          <div className="relative grid grid-cols-2 gap-6 border-t border-white/10 p-8 md:grid-cols-4 md:p-10">
            {["Brand Strategy", "Brand Identity Design", "Packaging Design", "Creative Direction"].map((c, i) => (
              <div key={c}>
                <div className="text-xs font-semibold text-primary">#0{i + 1}</div>
                <div className="mt-1 text-sm font-medium text-white">{c}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Trusted strip */}
        <div className="glass-strong mt-6 flex flex-wrap items-center justify-between gap-6 rounded-3xl px-8 py-6">
          <div className="text-sm font-semibold">Trusted by Concepts<br /><span className="text-muted-foreground font-normal">I've helped shape</span></div>
          {["Supa Blox", "Hype Blox", "Frame Blox", "Ultra Blox"].map((b, i) => {
            const Icon = [Sparkles, Zap, Target, Rocket][i];
            return (
              <div key={b} className="flex items-center gap-2 text-sm font-semibold text-white/90">
                <Icon className="h-5 w-5 text-primary" /> {b}
              </div>
            );
          })}
        </div>
      </section>

      {/* ABOUT */}
      <section id="about" className="relative z-10 mx-auto max-w-7xl px-6 py-24">
        <div className="grid gap-10 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <p className="text-sm font-semibold text-primary">Behind the Designs</p>
            <h2 className="mt-3 font-display text-4xl font-bold md:text-5xl">
              Shaping Experiences That Make Life Simpler
            </h2>
          </div>
          <div className="lg:col-span-7">
            <p className="font-display text-2xl font-semibold leading-snug">
              I'm a product-minded designer focused on building clean, intuitive brand systems that solve real-world problems.
            </p>
            <p className="mt-4 text-muted-foreground">
              Passion for branding, creative thinking, and a modern design approach — with obsessive
              attention to detail. My workflow is collaborative and client-focused, committed to
              delivering high-quality visual identities that stand the test of time.
            </p>
            <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-4">
              {stats.map(s => <StatCard key={s.label} {...s} />)}
            </div>
          </div>
        </div>
      </section>

      {/* SKILLS */}
      <section className="relative z-10 mx-auto max-w-7xl px-6 py-16">
        <SectionHeader eyebrow="Toolkit" title="Skills & Craft" />
        <div className="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {skills.map(s => (
            <div key={s.name} className="glass group rounded-2xl p-5 transition-all duration-300 hover:-translate-y-1 hover:ember-glow">
              <div className="flex items-center gap-3">
                <div className="grid h-11 w-11 place-items-center rounded-xl bg-ember text-white">
                  <s.icon className="h-5 w-5" />
                </div>
                <div className="flex-1">
                  <div className="flex justify-between text-sm font-semibold">
                    <span>{s.name}</span>
                    <span className="text-primary">{s.level}%</span>
                  </div>
                  <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/10">
                    <div className="h-full rounded-full bg-ember transition-all duration-1000 group-hover:brightness-125" style={{ width: `${s.level}%` }} />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* SERVICES */}
      <section id="services" className="relative z-10 mx-auto max-w-7xl px-6 py-24">
        <SectionHeader eyebrow="What I Offer" title="Services Built Around Your Brand" />
        <div className="mt-12 grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
          {services.map((s, i) => (
            <div key={s.title} className="glass group relative overflow-hidden rounded-3xl p-7 transition-all duration-300 hover:-translate-y-2">
              <div className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full opacity-0 blur-3xl transition-opacity duration-500 group-hover:opacity-40" style={{ background: "var(--gradient-ember)" }} />
              <div className="relative">
                <div className="grid h-14 w-14 place-items-center rounded-2xl bg-ember text-white ember-glow">
                  <s.icon className="h-6 w-6" />
                </div>
                <h3 className="mt-5 font-display text-xl font-semibold">{s.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.desc}</p>
                <button className="mt-5 inline-flex items-center gap-1.5 text-sm font-semibold text-primary transition-transform group-hover:translate-x-1">
                  Learn more <ArrowRight className="h-4 w-4" />
                </button>
              </div>
              <div className="absolute bottom-3 right-4 text-6xl font-bold text-white/5">0{i + 1}</div>
            </div>
          ))}
        </div>
      </section>

      {/* PORTFOLIO */}
      <section id="portfolio" className="relative z-10 mx-auto max-w-7xl px-6 py-16">
        <SectionHeader eyebrow="Concept Work" title="Selected Portfolio" />
        <div className="mt-8 flex flex-wrap gap-2">
          {filters.map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`rounded-full px-4 py-2 text-sm font-medium transition-all ${
                filter === f ? "bg-ember text-white ember-glow" : "glass text-muted-foreground hover:text-foreground"
              }`}
            >
              {f}
            </button>
          ))}
        </div>
        <div className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filtered.map(p => (
            <article key={p.title} className="glass group overflow-hidden rounded-3xl transition-all duration-300 hover:-translate-y-2 hover:ember-glow">
              <div
                className="relative flex h-48 items-end p-5"
                style={{ background: `linear-gradient(135deg, ${p.palette[0]}, ${p.palette[1]})` }}
              >
                <div className="absolute inset-0 opacity-30 mix-blend-overlay" style={{
                  backgroundImage: "radial-gradient(circle at 30% 30%, rgba(255,255,255,0.4), transparent 60%)"
                }} />
                <div className="relative">
                  <div className="text-xs font-semibold uppercase tracking-widest text-white/80">{p.category}</div>
                  <h3 className="mt-1 font-display text-2xl font-bold text-white">{p.title}</h3>
                </div>
              </div>
              <div className="p-5">
                <p className="text-sm text-muted-foreground">{p.desc}</p>
                <div className="mt-4 flex items-center gap-2">
                  {p.palette.map(c => (
                    <span key={c} className="h-6 w-6 rounded-full border border-white/20" style={{ background: c }} />
                  ))}
                </div>
                <div className="mt-4 flex items-center justify-between text-xs text-muted-foreground">
                  <span>{p.tools}</span>
                  <button className="inline-flex items-center gap-1 font-semibold text-primary transition-transform hover:translate-x-1">
                    View <ArrowRight className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* PROCESS */}
      <section className="relative z-10 mx-auto max-w-7xl px-6 py-24">
        <SectionHeader eyebrow="How I Work" title="The Design Process" />
        <div className="relative mt-14 grid grid-cols-1 gap-6 md:grid-cols-5">
          <div className="pointer-events-none absolute left-6 right-6 top-7 hidden h-px md:block" style={{ background: "linear-gradient(90deg, transparent, oklch(0.72 0.19 45 / 0.6), transparent)" }} />
          {process.map((p, i) => (
            <div key={p.title} className="glass relative rounded-2xl p-6 text-center">
              <div className="relative mx-auto grid h-14 w-14 place-items-center rounded-full bg-ember text-white ember-glow">
                <p.icon className="h-6 w-6" />
              </div>
              <div className="mt-3 text-xs font-bold text-primary">STEP 0{i + 1}</div>
              <h3 className="mt-1 font-display text-lg font-semibold">{p.title}</h3>
              <p className="mt-2 text-xs text-muted-foreground">{p.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* SOFTWARE */}
      <section className="relative z-10 mx-auto max-w-7xl px-6 py-16">
        <SectionHeader eyebrow="Software Expertise" title="Tools of the Trade" />
        <div className="mt-10 grid grid-cols-2 gap-6 md:grid-cols-4">
          {software.map(s => (
            <div key={s.name} className="glass rounded-3xl p-8 text-center transition-transform hover:-translate-y-1">
              <div className="relative mx-auto h-28 w-28">
                <svg viewBox="0 0 100 100" className="h-full w-full -rotate-90">
                  <circle cx="50" cy="50" r="42" fill="none" stroke="oklch(1 0 0 / 0.1)" strokeWidth="8" />
                  <circle
                    cx="50" cy="50" r="42" fill="none" stroke="url(#gr)" strokeWidth="8"
                    strokeLinecap="round"
                    strokeDasharray={`${2 * Math.PI * 42}`}
                    strokeDashoffset={`${2 * Math.PI * 42 * (1 - s.level / 100)}`}
                    style={{ transition: "stroke-dashoffset 1.5s ease" }}
                  />
                  <defs>
                    <linearGradient id="gr" x1="0" y1="0" x2="1" y2="1">
                      <stop offset="0%" stopColor="oklch(0.72 0.19 45)" />
                      <stop offset="100%" stopColor="oklch(0.55 0.22 25)" />
                    </linearGradient>
                  </defs>
                </svg>
                <div className="absolute inset-0 grid place-items-center font-display text-xl font-bold">{s.level}%</div>
              </div>
              <div className="mt-4 font-display font-semibold">{s.name}</div>
            </div>
          ))}
        </div>
      </section>

      {/* WHY */}
      <section className="relative z-10 mx-auto max-w-7xl px-6 py-24">
        <SectionHeader eyebrow="Why Work With Me" title="What Sets the Work Apart" />
        <div className="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {whys.map(w => (
            <div key={w.title} className="glass rounded-2xl p-6 transition-all hover:-translate-y-1 hover:ember-glow">
              <div className="grid h-12 w-12 place-items-center rounded-xl bg-ember text-white">
                <w.icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 font-display text-lg font-semibold">{w.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{w.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="relative z-10 mx-auto max-w-7xl px-6 py-16">
        <SectionHeader eyebrow="Kind Words" title="Client Testimonials" />
        <div className="mt-10 grid grid-cols-1 gap-6 md:grid-cols-3">
          {[0, 1, 2].map(i => (
            <div key={i} className="glass rounded-3xl p-8">
              <div className="flex gap-1 text-primary">
                {[...Array(5)].map((_, k) => <Star key={k} className="h-4 w-4 fill-current" />)}
              </div>
              <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
                Client testimonials will be featured here as I collaborate with brands and businesses.
              </p>
              <div className="mt-6 flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-ember" />
                <div>
                  <div className="text-sm font-semibold">Future Collaborator</div>
                  <div className="text-xs text-muted-foreground">Your brand here</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CONTACT */}
      <section id="contact" className="relative z-10 mx-auto max-w-7xl px-6 py-24">
        <div className="glass-strong overflow-hidden rounded-[2.5rem] p-8 md:p-14">
          <div className="grid gap-10 lg:grid-cols-2">
            <div>
              <p className="text-sm font-semibold text-primary">Let's Talk</p>
              <h2 className="mt-3 font-display text-4xl font-bold md:text-5xl">
                Let's Build Something <span className="text-gradient-ember">Amazing</span> Together
              </h2>
              <p className="mt-4 text-muted-foreground">
                Have a brand to launch or refresh? I'd love to hear about it. Reach out and let's
                start a conversation about your visual identity.
              </p>
              <div className="mt-8 space-y-4">
                {[
                  { icon: Mail, label: "Email", value: "jenniferdivya25@gmail.com", href: "mailto:jenniferdivya25@gmail.com" },
                  { icon: Phone, label: "Phone", value: "+91 9543801011", href: "tel:+919543801011" },
                  { icon: Instagram, label: "Instagram", value: "djdesigner2026", href: "https://instagram.com/djdesigner2026" },
                ].map(c => (
                  <a key={c.label} href={c.href} className="glass flex items-center gap-4 rounded-2xl p-4 transition-transform hover:-translate-y-0.5">
                    <div className="grid h-11 w-11 place-items-center rounded-xl bg-ember text-white">
                      <c.icon className="h-5 w-5" />
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground">{c.label}</div>
                      <div className="font-medium">{c.value}</div>
                    </div>
                  </a>
                ))}
              </div>
            </div>

            <ContactForm />

          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="relative z-10 border-t border-white/10">
        <div className="mx-auto max-w-7xl px-6 py-12">
          <div className="grid gap-10 md:grid-cols-4">
            <div className="md:col-span-2">
              <div className="font-display text-2xl font-bold">
                <span className="text-gradient-ember">S Divya</span> Jennifer
              </div>
              <p className="mt-2 text-sm text-muted-foreground">Freelance Graphic Designer — building brand identities that last.</p>
              <div className="mt-5 flex gap-2">
                {[Mail, Phone, Instagram].map((Icon, i) => (
                  <a key={i} href="#contact" className="glass grid h-10 w-10 place-items-center rounded-full transition-transform hover:scale-110">
                    <Icon className="h-4 w-4" />
                  </a>
                ))}
              </div>
            </div>
            <div>
              <div className="mb-3 text-sm font-semibold">Navigation</div>
              <ul className="space-y-2 text-sm text-muted-foreground">
                {nav.map(n => <li key={n.href}><a href={n.href} className="hover:text-foreground">{n.label}</a></li>)}
              </ul>
            </div>
            <div>
              <div className="mb-3 text-sm font-semibold">Services</div>
              <ul className="space-y-2 text-sm text-muted-foreground">
                {["Logo Design", "Brand Identity", "Packaging", "UI/UX", "Print"].map(s => (
                  <li key={s}><a href="#services" className="hover:text-foreground">{s}</a></li>
                ))}
              </ul>
            </div>
          </div>
          <div className="mt-10 flex flex-col justify-between gap-3 border-t border-white/10 pt-6 text-xs text-muted-foreground md:flex-row">
            <div>© {new Date().getFullYear()} S Divya Jennifer. All rights reserved.</div>
            <div>Designed & Developed with Creativity.</div>
          </div>
        </div>
      </footer>
    </div>
  );
}

function SectionHeader({ eyebrow, title }: { eyebrow: string; title: string }) {
  return (
    <div className="max-w-2xl">
      <p className="text-sm font-semibold text-primary">{eyebrow}</p>
      <h2 className="mt-2 font-display text-4xl font-bold md:text-5xl">{title}</h2>
    </div>
  );
}

function Field({ label, name, type = "text", placeholder }: { label: string; name: string; type?: string; placeholder?: string }) {
  return (
    <div>
      <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</label>
      <input
        name={name}
        type={type}
        required
        placeholder={placeholder}
        className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm outline-none transition-colors placeholder:text-muted-foreground/70 focus:border-primary/50"
      />
    </div>
  );
}

function ContactForm() {
  const formRef = useRef<HTMLFormElement>(null);
  const [sending, setSending] = useState(false);

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!formRef.current) return;
    setSending(true);
    try {
      await emailjs.sendForm(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, formRef.current, {
        publicKey: EMAILJS_PUBLIC_KEY,
      });
      toast.success("Message sent! I'll get back to you soon.");
      formRef.current.reset();
    } catch (err) {
      console.error(err);
      toast.error("Failed to send. Please try again or email directly.");
    } finally {
      setSending(false);
    }
  };

  return (
    <form ref={formRef} onSubmit={onSubmit} className="glass rounded-3xl p-6 md:p-8">
      <div className="grid gap-4">
        <Field label="Name" name="from_name" placeholder="Your full name" />
        <Field label="Email" name="reply_to" type="email" placeholder="you@brand.com" />
        <Field label="Subject" name="subject" placeholder="What's on your mind?" />
        <div>
          <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">Message</label>
          <textarea
            name="message"
            rows={5}
            required
            placeholder="Tell me about your project…"
            className="w-full resize-none rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm outline-none transition-colors placeholder:text-muted-foreground/70 focus:border-primary/50"
          />
        </div>
        <button
          type="submit"
          disabled={sending}
          className="group mt-2 inline-flex items-center justify-center gap-2 rounded-full bg-ember px-6 py-3.5 font-semibold text-white ember-glow transition-transform hover:scale-[1.02] disabled:opacity-70"
        >
          {sending ? "Sending..." : "Send Message"}
          {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />}
        </button>
      </div>
    </form>
  );
}

